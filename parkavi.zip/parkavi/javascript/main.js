var detail=[];
var det=[];
var content;
var img=[];
$.ajax({ 
    url: 'json/data.json', 
   type: 'GET'
            }).success(function(resp) {
                var response;
                response=JSON.parse(resp).productItems;
                /*var x=response.length;*/
                for(var i=0;i<response.length;i++){
img[i]=response[i].url;
detail[i]=response[i].Name;
det[i]=response[i].Price; 
newParagraph = $('<p />').attr({id:'para'}).text(detail[i])
paragraph=$('<p/>').attr({id:'para1'}).text(det[i]);
content=$('<img class="picture">').attr('src',img[i]);
block=$('<div class="block"/>').append(content).append(newParagraph).append(paragraph);
$('.empty').append(block);

                }
            }).error(function(error) {//if the retrieving of data is error,it will alert error message.
            alert(error);
        });


           $(document).ready(function(){
	$("#lap").click(function(){
		$(".container").css("display","none");
		$(".dynamic").css("display","block");
	})
	$('.dropBox').on('change',function(){
        var s=$(this).val();
         console.log(s);
         if(s=="price"){

         }
    }) 
})