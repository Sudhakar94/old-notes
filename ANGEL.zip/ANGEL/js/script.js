$(document).ready(function(){
	$("#plus").click(function(){
		$(".wrapper").css("display","none");
		$(".container").css("display","block");
		$(".note").val("");
		$(".des").val("");
	})
	$(".ok").click(function(){
		var d = new Date();
		var month = d.getMonth()+1;
		var day = d.getDate();
		var output = day+"/"+month+"/"+d.getFullYear();
     	var details = localStorage.details?JSON.parse(localStorage.details):[];
     	console.log(details);
		var det = JSON.stringify
		({
			title : $(".note").val(),
			description : $(".des").val(),
			created: output
		});
		console.log(det);
		details.push(det);
		console.log(details);
     	localStorage.setItem("details",JSON.stringify(details));
     	console.log(localStorage.details);
     	detail=JSON.parse(localStorage.getItem("details"));
     	console.log(detail);
     	var tableData;
     	$('tbody').empty();
		for(var i=0;i<detail.length;i++)
	{
		var data=JSON.parse(detail[i]);
		tableData=tableData+"<tr><td>"+data.title+"</td><td>"+data.description+
     		"</td><td>"+data.created+"</td></tr>";
	}
		$("table").append(tableData);
		$(".wrapper").css("display","block");
		$(".container").css("display","none");
	})
	$("#asc").click(function(){
		var rows = $('table tbody  tr').get();
		rows.sort(function(a, b) {
		var A = $(a).children('td').eq(0).text().toUpperCase();
		var B = $(b).children('td').eq(0).text().toUpperCase();
		if(A < B) {
    		return -1;
  		}
		if(A > B) {
    		return 1;
  		}
		return 0;
	});
	$.each(rows, function(index, row) {
    	$('table').children('tbody').append(row);
  	});
	})
	$("#desc").click(function(){
		var rows = $('table tbody  tr').get();
		rows.sort(function(a, b) {
		var A = $(a).children('td').eq(0).text().toUpperCase();
		var B = $(b).children('td').eq(0).text().toUpperCase();
		if(A > B) {
    		return -1;
  		}
		if(A < B) {
    		return 1;
  		}
		return 0;
	});
	$.each(rows, function(index, row) {
    	$('table').children('tbody').append(row);
  	});
	})
})