      var detail=[]; //i created an empty array to get the key and pair value from json file 
      var newParagraph;
      var img=[];
   $.ajax({ //To make ajax call in jquery we have to use "$.ajax" where as in angular js we use "$http"
            url: 'json/data.json', //This is url path of that json file
            type: 'GET'//In jquery we use "type' instead of "method" (in angular js) get type is to retrieve the dat from json
        }).success(function(resp) { //if the retrieving of data is success it will do further function which i done below here for get the data from json file we have to use "resp" where as in angular js we use "data" 
            var response;//i created an response variable for to get json fromat data
           response=JSON.parse(resp).ctsEmployees; //here i just parse the data into json format i.e,[object,obeject];
            // alert(response);
            for(var i=0;i<response.length;i++){
              detail[i]=response[i].name+" "+response[i].id; //By for loop i just push the data into the detail array which i created first
              newParagraph = $('<p />').attr({id:'para'}).text(detail[i])//and i dynamically create the paragragh tag to insert dat data
              $('.myDiv').append(newParagraph);//here i just append dat paragraph to static div which i created in html page.
              $('.myDiv,.imgdiv').css({"display":"none"});
			       img[i]=response[i].url//image url
             imgDom=$('<img />').attr('src',img[i]);
             $('.imgdiv').append(imgDom);
             }
        }).error(function(error) {//if the retrieving of data is error,it will alert error message.
            alert(error);
        });
		 var something= $('<input/>').attr({ id:'btnhidejson',type: 'button', name:'btn1', value:'Ok'});
		 $('.myDiv').append(something);
   $('#btnshowjson').on('click', function() {
    $('.myDiv,.imgdiv').toggle();
	$('body').css({"background":"#696565"});
    });	
    $('#btnhidejson').on('click', function() { 
     $('.myDiv,.imgdiv').css({"display":"none"});//i just add css property to hide the paragragh which is have that data.
     $('body').css({"background":"#FFF"});
	 });
